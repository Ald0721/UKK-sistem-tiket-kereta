<footer>
    <p>&copy; 2025 E-Tiket - All Rights Reserved</p>
    <a href="privacy_policy.php" style="color: white;">Privacy Policy</a> | 
    <a href="terms_of_service.php" style="color: white;">Terms of Service</a>
</footer>
